
import './App.css'
import Chat from './Components/chatbot'
import UnassignedSession from './Components/UnassigendSession'
import { Route,Routes } from 'react-router-dom';
function App() {
  
  // const handleAccept = (session) => {
  //   // Handle the accepted session here
  //   console.log("Accepted session:", session);
  //   // You can redirect to another component or perform other actions here
  // };
  return (
    <>
<Routes>
      <Route path="/" element={<UnassignedSession onAccept={(session) => console.log(session)} />} />
      <Route path="/chat" element={<Chat />} />
    </Routes>
    </>
  )
}

export default App
