import { useState, useRef, useEffect } from "react";
import PropTypes from "prop-types";
import "./Chat.css";
import { useLocation } from "react-router-dom";

const Chat = () => {
  const location = useLocation();
  const sessionid = location.state?.sessionid;
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [isSending, setIsSending] = useState(false);
  const chatEndRef = useRef(null);
  const [chatstatus, setChatStatus] = useState(false);
  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleSend = () => {
    if (input.trim() && !isSending) {
      setIsSending(true);
      const userMessage = { text: input, type: "user" };
      setMessages((prevMessages) => [...prevMessages, userMessage]);
      setInput("");

      setTimeout(() => {
        handleAgentChat(userMessage.text); // Pass the current message text
        setIsSending(false);
      }, 1000);
    }
  };

  const assignSessionToUser = (sessionid) => {
    return fetch(
      `https://prod-00.centralindia.logic.azure.com:443/workflows/d5ff23bfc0c14dd9ba7c43102cb75955/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=2yzH7vLH0OmAt3Q1FENyZARjTUj3wMZwg4KnvCj3hDs`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          sessionid,
          userId: "e25836ad-eb3f-ef11-a317-6045bd72ef97",
        }),
      }
    )
      .then((response) => response.ok)
      .catch((error) => {
        console.error("Error assigning session:", error);
        return false;
      });
  };

  const postMessage = (sessionid, message) => {
    fetch(
      "https://prod-10.centralindia.logic.azure.com:443/workflows/16a28656fb824c0d809536590a012582/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=V2-Blav3jQ21Vsa9nUTExa5w_sz4c03UIFf94cuYs74",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          sessionid,
          message,
        }),
      }
    )
      .then((response) => {
        if (response.ok) {
          // Fetch messages after sending
          fetchMessages(sessionid);
          setIsSending(false);
          setChatStatus(true);
        }
      })
      .catch((error) => {
        console.error("Error posting message:", error);
      });
  };

  const fetchMessages = (sessionid) => {
    fetch(
      "https://prod-16.centralindia.logic.azure.com/workflows/2d4db4ebe56b4e248de18b5f5d0ae0e9/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=UiVZKTYIPjQAvonLCQkS4pH-Qe0XEXVBF-DImCroKbI",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          sessionid,
        }),
      }
    )
      .then((response) => response.json())
      .then((data) => {
        const newMessages = data.map((msg) => ({
          text: msg.message,
          type: "bot",
        }));
        setMessages((prevMessages) => [...prevMessages, ...newMessages]);
        // Set messages as read
        data.forEach((msg) => setReadStatus(sessionid, msg.chatid));
      })
      .catch((error) => console.error("Error fetching messages:", error));
  };

  const setReadStatus = (sessionid, chatid) => {
    fetch(
      "https://prod-14.centralindia.logic.azure.com:443/workflows/8647f31cda4443118c7c14172a5b52aa/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=2TCKAUJp1wY3gPo68ZRHH0UJ74kcVmp6KswF_WyXAtU",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          sessionid,
          chatid,
        }),
      }
    )
      .then((response) => {
        if (response.ok) {
          console.log("Message marked as read.");
        } else {
          console.error("Failed to set message as read.");
        }
      })
      .catch((error) => console.error("Error setting read status:", error));
  };

  const handleAgentChat = (message) => {
    setIsSending(true);

    if (!chatstatus) {
      assignSessionToUser(sessionid)
        .then(() => {
          setIsSending(false);
        })
        // .then((response) => {
        //   if (response.ok) {
        //     // setChatStatus(true);
        //   } else {
        //     setMessages((prevMessages) => [
        //       ...prevMessages,
        //       { text: "Failed to connect to a live agent.", type: "bot" },
        //     ]);
        //   }
          
        // })
     
    } 
      postMessage(sessionid, message);
    
  };

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  useEffect(() => {
    let intervalId;
    if (sessionid) {
      intervalId = setInterval(() => {
        fetchMessages(sessionid);
      }, 1000);
    }

    // Cleanup interval on component unmount
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [sessionid]);

  useEffect(() => {
    // Automatically send the initial message
    if (!chatstatus) {
      handleAgentChat(""); // Passing empty string to initiate chat
    }
  }, [sessionid]);

  return (
    <>
      <div className={`chat active`}>
        <div className="chat-cont">
          <div className="chat-top">
            <img src="" alt="" />
          </div>
          <div className="chat-body">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`chat-message ${
                  msg?.type === "user" ? "chat-query" : "chat-response"
                }`}
              >
                <div
                  className={`chat-text ${
                    msg?.type === "user" ? "chat-query-text" : ""
                  }`}
                >
                  {msg?.text}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
            {messages.some(
              (msg) => msg?.text === "Would you like to chat with a live agent?"
            ) && (
              <div
                className="chat-live-agent-button"
                onClick={handleAgentChat}
              >
                Chat with Live Agent
              </div>
            )}
          </div>
          <div className="chat-input">
            <input
              type="text"
              value={input}
              onChange={handleInputChange}
              onKeyPress={(e) => {
                if (e.key === "Enter") handleSend();
              }}
              placeholder="Type a message..."
              disabled={isSending}
            />
            <button onClick={handleSend} disabled={isSending}>
              Send
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

Chat.propTypes = {
  sessionid: PropTypes.string.isRequired,
};

export default Chat;
