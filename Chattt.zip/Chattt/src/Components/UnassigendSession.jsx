// import PropTypes from "prop-types";
// import { useState } from "react";
// import "./Chat.css";

// const UnassignedSession = ({ onAccept }) => {
//   const [sessions, setSessions] = useState([
//   { sessionid: "abc-1223", name: "Jhon", unreadCount: "2" },
//   { sessionid: "def-4567", name: "David", unreadCount: "5" },
//   { sessionid: "ghi-7890", name: "Head", unreadCount: "3" },
//   { sessionid: "jkl-1234", name: "Sachin", unreadCount: "1" },
//   { sessionid: "mno-5678", name: "Ponting", unreadCount: "4" },
//   { sessionid: "pqr-9012", name: "Miller", unreadCount: "6" },
//   { sessionid: "stu-3456", name: "Raj", unreadCount: "2" },
//   { sessionid: "vwx-7890", name: "Sanket", unreadCount: "3" },
//   { sessionid: "yz-1123", name: "Sagar", unreadCount: "1" },
//   { sessionid: "abc-3345", name: "Ajay", unreadCount: "7" },
//   { sessionid: "def-6678", name: "Rahul", unreadCount: "8" },
//   { sessionid: "ghi-9901", name: "Aman", unreadCount: "2" },
//   { sessionid: "jkl-2345", name: "Shyam", unreadCount: "5" },
//   { sessionid: "mno-6789", name: "Anand", unreadCount: "4" },
//   { sessionid: "pqr-1234", name: "Kirti", unreadCount: "6" },
//   { sessionid: "stu-5678", name: "Yash", unreadCount: "3" },
//   { sessionid: "vwx-9101", name: "Samiksha", unreadCount: "2" },
//   { sessionid: "yz-2345", name: "Rishabh", unreadCount: "1" },
//   { sessionid: "abc-6789", name: "Abhishek", unreadCount: "4" },
//   { sessionid: "def-0123", name: "Ritik", unreadCount: "5" }
//   ]);

//   const handleAccept = (session) => {
//     onAccept(session);
//   };

//   const handleSkip = (sessionid) => {
//     setSessions(sessions.filter(session => session.sessionid !== sessionid));
//   };

//   return (
//     <div>
//       <h3 className="title">Unassigned Sessions</h3>
//       <ul>
//         {sessions.map((session) => (
//           <li key={session.sessionid} className="session-item">
//             <span>{session.name}</span>
//             <span className="call_to_action">
//             <button className="sucess" onClick={() => handleAccept(session)}>Accept</button>
//             <button className="alert" onClick={() => handleSkip(session.sessionid)}>Skip</button>
//             </span>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// UnassignedSession.propTypes = {
//   onAccept: PropTypes.func.isRequired
// };

// export default UnassignedSession;
import PropTypes from "prop-types";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Chat.css";

const UnassignedSession = ({ onAccept }) => {
  const [sessions, setSessions] = useState([]);
  const navigate = useNavigate();

  // Fetch session data from the API when the component mounts
  useEffect(() => {
    const fetchSessions = async () => {
      try {
        const response = await fetch(
          "https://prod-09.centralindia.logic.azure.com/workflows/f5339ed288aa4f5c9d2fe90c09b62d20/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=dMsIBN52F7Sa_bQoUM7Lbr3jJd8VOtj_Fo0Mm26DUU4"
        );
        const data = await response.json();
        console.log(data,"dsdsjdsgd")
        setSessions(data);
      } catch (error) {
        console.error("Error fetching sessions:", error);
      }
    };

    fetchSessions();
  }, []);

  const handleAccept = (session) => {
    onAccept(session);
    navigate("/chat", { state: { sessionid: session.sessionid } }); 
  };

  const handleSkip = (sessionid) => {
    setSessions(sessions.filter((session) => session.sessionid !== sessionid));
  };

  return (
    <div>
      <h3 className="title">Unassigned Sessions</h3>
      <ul>
        {sessions.map((session) => (
           <li key={session.sessionid} className="session-item">
             <span>{session.name}</span>
             <span className="call_to_action">
            <button className="sucess" onClick={() => handleAccept(session)}>Accept</button>
            <button className="alert" onClick={() => handleSkip(session.sessionid)}>Skip</button>
             </span>
          </li>
         ))}
       </ul>
    </div>
  );
};

UnassignedSession.propTypes = {
  onAccept: PropTypes.func.isRequired,
};

export default UnassignedSession;
